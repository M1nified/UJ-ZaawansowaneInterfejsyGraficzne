﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Threads
    {
        public Threads()
        {
            var job1 = new Job1();
            var job2 = new Job2();
            var job3 = new Job1(3);
            List<Thread> threads = new List<Thread>();
            threads.Add(new Thread(new ThreadStart(job1.Run)));
            threads.Add(new Thread(new ThreadStart(job2.Run)));
            threads.Add(new Thread(new ThreadStart(job1.Run)));
            threads.Add(new Thread(new ThreadStart(job2.Run)));
            threads.Add(new Thread(new ThreadStart(job3.Run)));

            foreach (var thread in threads)
            {
                thread.Start();
            }

            foreach (var thread in threads)
            {
                thread.Join();
            }
        }
    }
}
