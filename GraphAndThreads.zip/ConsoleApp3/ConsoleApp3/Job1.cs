﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace ConsoleApp3
{
    class Job1
    {
        int x;
        public Job1(int x = 1)
        {
            this.x = x;
        }

        public void Run()
        {
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("" + x + " Working thread...");
                Thread.Sleep(100);
            }
        }
    }
}
