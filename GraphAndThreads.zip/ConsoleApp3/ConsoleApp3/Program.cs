﻿using System;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            var gr = new Graph(10);
            Console.WriteLine(gr.NeighboursToString);

            new Threads();

        }
    }
}
