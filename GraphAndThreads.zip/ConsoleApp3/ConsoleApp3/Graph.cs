﻿using System;
using System.Collections.Generic;

namespace ConsoleApp3
{
    class Graph
    {
        List<List<bool>> neighbours;
        int size;
        public Graph(int size)
        {
            this.size = size;
            neighbours = new List<List<bool>>();
            randomize();
        }

        private void randomize()
        {
            var rand = new Random();
            for (int i = 0; i < size; i++)
            {
                List<bool> row = new List<bool>();
                neighbours.Add(row);
                for (int j = 0; j < size; j++)
                {
                    row.Add(false);
                }
            }
            for (int i = 0; i < size; i++)
            {
                for (int j = i; j < size; j++)
                {
                    if (i == j) continue;
                    var val = (rand.Next(0, 2) == 0);
                    neighbours[i][j] = val;
                    neighbours[j][i] = val;
                }

            }
        }

        public string NeighboursToString
        {
            get
            {
                string output = "";
                foreach (var row in neighbours)
                {
                    foreach (var state in row)
                    {
                        output += (state ? 1 : 0) + " ";
                    }
                    output += "\n";
                }
                return output;
            }
        }
    }
}
