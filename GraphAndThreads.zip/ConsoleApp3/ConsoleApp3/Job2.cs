﻿using System;
using System.Threading;

namespace ConsoleApp3
{
    class Job2
    {
        int x;
        public Job2(int x = 2)
        {
            this.x = x;
        }

        public void Run()
        {
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("" + x + " Working thread...");
                Thread.Sleep(100);
            }

        }
    }
}
